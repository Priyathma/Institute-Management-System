﻿namespace ADMIN
{
    partial class STUDENT
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(STUDENT));
            this.gunaAdvenceButton12 = new Guna.UI.WinForms.GunaAdvenceButton();
            this.gunaAdvenceButton11 = new Guna.UI.WinForms.GunaAdvenceButton();
            this.gunaAdvenceButton10 = new Guna.UI.WinForms.GunaAdvenceButton();
            this.gunaAdvenceButton9 = new Guna.UI.WinForms.GunaAdvenceButton();
            this.gunaAdvenceButton8 = new Guna.UI.WinForms.GunaAdvenceButton();
            this.gunaAdvenceButton7 = new Guna.UI.WinForms.GunaAdvenceButton();
            this.gunaAdvenceButton6 = new Guna.UI.WinForms.GunaAdvenceButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            // 
            // gunaAdvenceButton12
            // 
            this.gunaAdvenceButton12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaAdvenceButton12.AnimationHoverSpeed = 0.07F;
            this.gunaAdvenceButton12.AnimationSpeed = 0.03F;
            this.gunaAdvenceButton12.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.gunaAdvenceButton12.BorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton12.CheckedBaseColor = System.Drawing.Color.Gray;
            this.gunaAdvenceButton12.CheckedBorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton12.CheckedForeColor = System.Drawing.Color.White;
            this.gunaAdvenceButton12.CheckedImage = ((System.Drawing.Image)(resources.GetObject("gunaAdvenceButton12.CheckedImage")));
            this.gunaAdvenceButton12.CheckedLineColor = System.Drawing.Color.DimGray;
            this.gunaAdvenceButton12.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaAdvenceButton12.FocusedColor = System.Drawing.Color.Empty;
            this.gunaAdvenceButton12.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaAdvenceButton12.ForeColor = System.Drawing.Color.White;
            this.gunaAdvenceButton12.Image = null;
            this.gunaAdvenceButton12.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaAdvenceButton12.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(58)))), ((int)(((byte)(170)))));
            this.gunaAdvenceButton12.Location = new System.Drawing.Point(1139, 16);
            this.gunaAdvenceButton12.Name = "gunaAdvenceButton12";
            this.gunaAdvenceButton12.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.gunaAdvenceButton12.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton12.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaAdvenceButton12.OnHoverImage = null;
            this.gunaAdvenceButton12.OnHoverLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(58)))), ((int)(((byte)(170)))));
            this.gunaAdvenceButton12.OnPressedColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton12.Size = new System.Drawing.Size(180, 42);
            this.gunaAdvenceButton12.TabIndex = 17;
            this.gunaAdvenceButton12.Text = "TIMETABLE";
            this.gunaAdvenceButton12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaAdvenceButton12.Click += new System.EventHandler(this.gunaAdvenceButton12_Click);
            // 
            // gunaAdvenceButton11
            // 
            this.gunaAdvenceButton11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaAdvenceButton11.AnimationHoverSpeed = 0.07F;
            this.gunaAdvenceButton11.AnimationSpeed = 0.03F;
            this.gunaAdvenceButton11.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.gunaAdvenceButton11.BorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton11.CheckedBaseColor = System.Drawing.Color.Gray;
            this.gunaAdvenceButton11.CheckedBorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton11.CheckedForeColor = System.Drawing.Color.White;
            this.gunaAdvenceButton11.CheckedImage = ((System.Drawing.Image)(resources.GetObject("gunaAdvenceButton11.CheckedImage")));
            this.gunaAdvenceButton11.CheckedLineColor = System.Drawing.Color.DimGray;
            this.gunaAdvenceButton11.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaAdvenceButton11.FocusedColor = System.Drawing.Color.Empty;
            this.gunaAdvenceButton11.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaAdvenceButton11.ForeColor = System.Drawing.Color.White;
            this.gunaAdvenceButton11.Image = null;
            this.gunaAdvenceButton11.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaAdvenceButton11.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(58)))), ((int)(((byte)(170)))));
            this.gunaAdvenceButton11.Location = new System.Drawing.Point(953, 16);
            this.gunaAdvenceButton11.Name = "gunaAdvenceButton11";
            this.gunaAdvenceButton11.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.gunaAdvenceButton11.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton11.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaAdvenceButton11.OnHoverImage = null;
            this.gunaAdvenceButton11.OnHoverLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(58)))), ((int)(((byte)(170)))));
            this.gunaAdvenceButton11.OnPressedColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton11.Size = new System.Drawing.Size(180, 42);
            this.gunaAdvenceButton11.TabIndex = 16;
            this.gunaAdvenceButton11.Text = "PARENT DETAILS";
            this.gunaAdvenceButton11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaAdvenceButton11.Click += new System.EventHandler(this.gunaAdvenceButton11_Click);
            // 
            // gunaAdvenceButton10
            // 
            this.gunaAdvenceButton10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaAdvenceButton10.AnimationHoverSpeed = 0.07F;
            this.gunaAdvenceButton10.AnimationSpeed = 0.03F;
            this.gunaAdvenceButton10.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.gunaAdvenceButton10.BorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton10.CheckedBaseColor = System.Drawing.Color.Gray;
            this.gunaAdvenceButton10.CheckedBorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton10.CheckedForeColor = System.Drawing.Color.White;
            this.gunaAdvenceButton10.CheckedImage = ((System.Drawing.Image)(resources.GetObject("gunaAdvenceButton10.CheckedImage")));
            this.gunaAdvenceButton10.CheckedLineColor = System.Drawing.Color.DimGray;
            this.gunaAdvenceButton10.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaAdvenceButton10.FocusedColor = System.Drawing.Color.Empty;
            this.gunaAdvenceButton10.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaAdvenceButton10.ForeColor = System.Drawing.Color.White;
            this.gunaAdvenceButton10.Image = null;
            this.gunaAdvenceButton10.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaAdvenceButton10.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(58)))), ((int)(((byte)(170)))));
            this.gunaAdvenceButton10.Location = new System.Drawing.Point(767, 16);
            this.gunaAdvenceButton10.Name = "gunaAdvenceButton10";
            this.gunaAdvenceButton10.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.gunaAdvenceButton10.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton10.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaAdvenceButton10.OnHoverImage = null;
            this.gunaAdvenceButton10.OnHoverLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(58)))), ((int)(((byte)(170)))));
            this.gunaAdvenceButton10.OnPressedColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton10.Size = new System.Drawing.Size(180, 42);
            this.gunaAdvenceButton10.TabIndex = 15;
            this.gunaAdvenceButton10.Text = "CLASS FEES";
            this.gunaAdvenceButton10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaAdvenceButton10.Click += new System.EventHandler(this.gunaAdvenceButton10_Click);
            // 
            // gunaAdvenceButton9
            // 
            this.gunaAdvenceButton9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaAdvenceButton9.AnimationHoverSpeed = 0.07F;
            this.gunaAdvenceButton9.AnimationSpeed = 0.03F;
            this.gunaAdvenceButton9.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.gunaAdvenceButton9.BorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton9.CheckedBaseColor = System.Drawing.Color.Gray;
            this.gunaAdvenceButton9.CheckedBorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton9.CheckedForeColor = System.Drawing.Color.White;
            this.gunaAdvenceButton9.CheckedImage = ((System.Drawing.Image)(resources.GetObject("gunaAdvenceButton9.CheckedImage")));
            this.gunaAdvenceButton9.CheckedLineColor = System.Drawing.Color.DimGray;
            this.gunaAdvenceButton9.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaAdvenceButton9.FocusedColor = System.Drawing.Color.Empty;
            this.gunaAdvenceButton9.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaAdvenceButton9.ForeColor = System.Drawing.Color.White;
            this.gunaAdvenceButton9.Image = null;
            this.gunaAdvenceButton9.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaAdvenceButton9.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(58)))), ((int)(((byte)(170)))));
            this.gunaAdvenceButton9.Location = new System.Drawing.Point(581, 16);
            this.gunaAdvenceButton9.Name = "gunaAdvenceButton9";
            this.gunaAdvenceButton9.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.gunaAdvenceButton9.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton9.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaAdvenceButton9.OnHoverImage = null;
            this.gunaAdvenceButton9.OnHoverLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(58)))), ((int)(((byte)(170)))));
            this.gunaAdvenceButton9.OnPressedColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton9.Size = new System.Drawing.Size(180, 42);
            this.gunaAdvenceButton9.TabIndex = 14;
            this.gunaAdvenceButton9.Text = "ATTENDENCE";
            this.gunaAdvenceButton9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaAdvenceButton9.Click += new System.EventHandler(this.gunaAdvenceButton9_Click);
            // 
            // gunaAdvenceButton8
            // 
            this.gunaAdvenceButton8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaAdvenceButton8.AnimationHoverSpeed = 0.07F;
            this.gunaAdvenceButton8.AnimationSpeed = 0.03F;
            this.gunaAdvenceButton8.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.gunaAdvenceButton8.BorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton8.CheckedBaseColor = System.Drawing.Color.Gray;
            this.gunaAdvenceButton8.CheckedBorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton8.CheckedForeColor = System.Drawing.Color.White;
            this.gunaAdvenceButton8.CheckedImage = ((System.Drawing.Image)(resources.GetObject("gunaAdvenceButton8.CheckedImage")));
            this.gunaAdvenceButton8.CheckedLineColor = System.Drawing.Color.DimGray;
            this.gunaAdvenceButton8.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaAdvenceButton8.FocusedColor = System.Drawing.Color.Empty;
            this.gunaAdvenceButton8.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaAdvenceButton8.ForeColor = System.Drawing.Color.White;
            this.gunaAdvenceButton8.Image = null;
            this.gunaAdvenceButton8.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaAdvenceButton8.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(58)))), ((int)(((byte)(170)))));
            this.gunaAdvenceButton8.Location = new System.Drawing.Point(395, 16);
            this.gunaAdvenceButton8.Name = "gunaAdvenceButton8";
            this.gunaAdvenceButton8.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.gunaAdvenceButton8.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton8.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaAdvenceButton8.OnHoverImage = null;
            this.gunaAdvenceButton8.OnHoverLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(58)))), ((int)(((byte)(170)))));
            this.gunaAdvenceButton8.OnPressedColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton8.Size = new System.Drawing.Size(180, 42);
            this.gunaAdvenceButton8.TabIndex = 13;
            this.gunaAdvenceButton8.Text = "CLASSES";
            this.gunaAdvenceButton8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaAdvenceButton8.Click += new System.EventHandler(this.gunaAdvenceButton8_Click);
            // 
            // gunaAdvenceButton7
            // 
            this.gunaAdvenceButton7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaAdvenceButton7.AnimationHoverSpeed = 0.07F;
            this.gunaAdvenceButton7.AnimationSpeed = 0.03F;
            this.gunaAdvenceButton7.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.gunaAdvenceButton7.BorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton7.CheckedBaseColor = System.Drawing.Color.Gray;
            this.gunaAdvenceButton7.CheckedBorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton7.CheckedForeColor = System.Drawing.Color.White;
            this.gunaAdvenceButton7.CheckedImage = null;
            this.gunaAdvenceButton7.CheckedLineColor = System.Drawing.Color.DimGray;
            this.gunaAdvenceButton7.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaAdvenceButton7.FocusedColor = System.Drawing.Color.Empty;
            this.gunaAdvenceButton7.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaAdvenceButton7.ForeColor = System.Drawing.Color.White;
            this.gunaAdvenceButton7.Image = null;
            this.gunaAdvenceButton7.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaAdvenceButton7.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(58)))), ((int)(((byte)(170)))));
            this.gunaAdvenceButton7.Location = new System.Drawing.Point(209, 16);
            this.gunaAdvenceButton7.Name = "gunaAdvenceButton7";
            this.gunaAdvenceButton7.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.gunaAdvenceButton7.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton7.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaAdvenceButton7.OnHoverImage = null;
            this.gunaAdvenceButton7.OnHoverLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(58)))), ((int)(((byte)(170)))));
            this.gunaAdvenceButton7.OnPressedColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton7.Size = new System.Drawing.Size(180, 42);
            this.gunaAdvenceButton7.TabIndex = 12;
            this.gunaAdvenceButton7.Text = "STUDENT DETAILS";
            this.gunaAdvenceButton7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaAdvenceButton7.Click += new System.EventHandler(this.gunaAdvenceButton7_Click);
            // 
            // gunaAdvenceButton6
            // 
            this.gunaAdvenceButton6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gunaAdvenceButton6.AnimationHoverSpeed = 0.07F;
            this.gunaAdvenceButton6.AnimationSpeed = 0.03F;
            this.gunaAdvenceButton6.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.gunaAdvenceButton6.BorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton6.CheckedBaseColor = System.Drawing.Color.Gray;
            this.gunaAdvenceButton6.CheckedBorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton6.CheckedForeColor = System.Drawing.Color.White;
            this.gunaAdvenceButton6.CheckedImage = null;
            this.gunaAdvenceButton6.CheckedLineColor = System.Drawing.Color.DimGray;
            this.gunaAdvenceButton6.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaAdvenceButton6.FocusedColor = System.Drawing.Color.Empty;
            this.gunaAdvenceButton6.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaAdvenceButton6.ForeColor = System.Drawing.Color.White;
            this.gunaAdvenceButton6.Image = null;
            this.gunaAdvenceButton6.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaAdvenceButton6.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(58)))), ((int)(((byte)(170)))));
            this.gunaAdvenceButton6.Location = new System.Drawing.Point(23, 16);
            this.gunaAdvenceButton6.Name = "gunaAdvenceButton6";
            this.gunaAdvenceButton6.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.gunaAdvenceButton6.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton6.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaAdvenceButton6.OnHoverImage = null;
            this.gunaAdvenceButton6.OnHoverLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(58)))), ((int)(((byte)(170)))));
            this.gunaAdvenceButton6.OnPressedColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton6.Size = new System.Drawing.Size(180, 42);
            this.gunaAdvenceButton6.TabIndex = 11;
            this.gunaAdvenceButton6.Text = "REGISTRATION";
            this.gunaAdvenceButton6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaAdvenceButton6.Click += new System.EventHandler(this.gunaAdvenceButton6_Click);
            // 
            // panel1
            // 
            this.panel1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.panel1.Location = new System.Drawing.Point(23, 75);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1296, 667);
            this.panel1.TabIndex = 18;
            // 
            // STUDENT
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1342, 759);
            this.ControlBox = false;
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.gunaAdvenceButton12);
            this.Controls.Add(this.gunaAdvenceButton11);
            this.Controls.Add(this.gunaAdvenceButton10);
            this.Controls.Add(this.gunaAdvenceButton9);
            this.Controls.Add(this.gunaAdvenceButton8);
            this.Controls.Add(this.gunaAdvenceButton7);
            this.Controls.Add(this.gunaAdvenceButton6);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "STUDENT";
            this.Text = "Form3";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.Form3_Load);
            this.ResumeLayout(false);

        }

        #endregion
        private Guna.UI.WinForms.GunaAdvenceButton gunaAdvenceButton12;
        private Guna.UI.WinForms.GunaAdvenceButton gunaAdvenceButton11;
        private Guna.UI.WinForms.GunaAdvenceButton gunaAdvenceButton10;
        private Guna.UI.WinForms.GunaAdvenceButton gunaAdvenceButton9;
        private Guna.UI.WinForms.GunaAdvenceButton gunaAdvenceButton8;
        private Guna.UI.WinForms.GunaAdvenceButton gunaAdvenceButton7;
        private Guna.UI.WinForms.GunaAdvenceButton gunaAdvenceButton6;
        private System.Windows.Forms.Panel panel1;
    }
}